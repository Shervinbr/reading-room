# The reading room

A static interactive bookshelf, ready for GitHub Pages. Open index.html for a local preview.

## Change your books

Edit books.js. Copy a book object to add another spine, choosing a different color. Ratings are out of five. The current title, author, rating, and review are supplied example content. The illustrated cover is an original placeholder design, not the published book jacket.

To use an actual cover, put the image inside a covers folder and set cover to "covers/your-image.jpg".

## Publish on GitHub Pages

1. Create a repository on GitHub (public for GitHub Free).
2. Upload index.html, style.css, app.js, books.js, and .nojekyll to its root.
3. In repository Settings → Pages, choose Deploy from a branch, main, / (root), and Save.
4. GitHub provides your published address after deployment. You can configure a domain you own in the same Pages settings.

No build step or backend is required. Google Fonts are optional; the page falls back to system fonts without internet access.
